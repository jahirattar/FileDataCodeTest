﻿using FileData;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace FileDataTestCases
{
    [TestClass]
    public class FileDataTests
    {
        private readonly FileStatisticBusinessLogic _fileStatisticBusinessLogic;
        private readonly Moq.Mock<IFileStatistics<string>> _fileStatisticVersion;
        private readonly Moq.Mock<IFileStatistics<int>> _fileStatisticSize;

        public FileDataTests()
        {
            _fileStatisticVersion = new Moq.Mock<IFileStatistics<string>>();
            _fileStatisticSize = new Moq.Mock<IFileStatistics<int>>();
            _fileStatisticBusinessLogic = new FileStatisticBusinessLogic(_fileStatisticVersion.Object, _fileStatisticSize.Object);
        }

        [TestMethod]
        public void FileSize_With_Valid_Input()
        {
            _fileStatisticSize.Setup(a => a.GetFileStatistics("c:\abc")).Returns(1234);
            var fileSizeArgs1 = new string[] { "-s", "c:\abc" };
            var fileSizeArgs2 = new string[] { "--s", "c:\abc" };
            var fileSizeArgs3 = new string[] { "/s", "c:\abc" };
            var fileSizeArgs4 = new string[] { "--size", "c:\abc" };

            var fileStatistic1 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs1);
            var fileStatistic2 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs2);
            var fileStatistic3 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs3);
            var fileStatistic4 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs4);

            Assert.AreEqual(fileStatistic1, 1234);
            Assert.AreEqual(fileStatistic2, 1234);
            Assert.AreEqual(fileStatistic3, 1234);
            Assert.AreEqual(fileStatistic4, 1234);
        }

        [TestMethod]
        public void FileVersion_With_Valid_Input()
        {
            _fileStatisticVersion.Setup(a => a.GetFileStatistics("c:\abc")).Returns("1.0.2.0");

            var fileSizeArgs1 = new string[] { "-v", "c:\abc" };
            var fileSizeArgs2 = new string[] { "--v", "c:\abc" };
            var fileSizeArgs3 = new string[] { "/v", "c:\abc" };
            var fileSizeArgs4 = new string[] { "--version", "c:\abc" };

            var fileStatistic1 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs1);
            var fileStatistic2 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs2);
            var fileStatistic3 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs3);
            var fileStatistic4 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs4);

            Assert.AreEqual(fileStatistic1, "1.0.2.0");
            Assert.AreEqual(fileStatistic2, "1.0.2.0");
            Assert.AreEqual(fileStatistic3, "1.0.2.0");
            Assert.AreEqual(fileStatistic4, "1.0.2.0");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException), "Invalid arguments")]
        public void FileVersion_With_InValid_Input()
        {
            _fileStatisticVersion.Setup(a => a.GetFileStatistics("c:\abc")).Returns("1.0.2.0");

            var fileSizeArgs1 = new string[] { "-d", "c:\abc" };

            var fileStatistic1 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs1);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException), "Please enter two input arguments." +
                    "\n e.g. ‘-v c:/test.txt’ where '-v' is operation to perform and 'c:/test.txt' full path details of file")]
        public void FileVersion_With_OutOfRangeArgument_Exception()
        {
            _fileStatisticVersion.Setup(a => a.GetFileStatistics("c:\abc")).Returns("1.0.2.0");

            var fileSizeArgs1 = new string[] { "-d", "c:\abc", "sdas" };

            var fileStatistic1 = _fileStatisticBusinessLogic.ProcessFileStatisticData(fileSizeArgs1);
        }

    }
}
