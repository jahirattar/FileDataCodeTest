﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Unity;

namespace FileData
{
    public static class AppConfigurations
    {
        private static IUnityContainer _unityContainer = new UnityContainer();

        public static void LoadConfiguration()
        {
            _unityContainer.RegisterSingleton<IFileStatisticBusinessLogic, FileStatisticBusinessLogic>();
            _unityContainer.RegisterSingleton<IFileStatistics<string>, FileStatistics>();
            _unityContainer.RegisterSingleton<IFileStatistics<int>, FileStatistics>();
        }

        public static T Retrieve<T>()
        {
            return _unityContainer.Resolve<T>();
        }
    }
}
