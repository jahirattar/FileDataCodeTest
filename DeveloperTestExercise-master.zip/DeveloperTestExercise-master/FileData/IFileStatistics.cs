﻿namespace FileData
{
    /// <summary>
    /// Generic interface for getting file statistics
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IFileStatistics <T>
    {
        T GetFileStatistics(string filePath);
    }
}
