﻿using System;
using System.Linq;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            //Setup unity bindings
            AppConfigurations.LoadConfiguration();
            
            GetFileDetails(args);
        }

        private static void GetFileDetails(string[] args)
        {
            try
            {
                var fileStaticsBusinessLogic = AppConfigurations.Retrieve<FileStatisticBusinessLogic>();
                var fileStatistics = fileStaticsBusinessLogic.ProcessFileStatisticData(args);
                Console.WriteLine("File statistic : {0}", fileStatistics);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
           
        }

    }
}
