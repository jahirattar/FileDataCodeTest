﻿    using System;

namespace FileData
{
    public class FileStatistics : IFileStatistics<int>, IFileStatistics<string>
    {
        private readonly ThirdPartyTools.FileDetails _fileDetails;

        public FileStatistics()
        {
            _fileDetails = new ThirdPartyTools.FileDetails();
        }

        string IFileStatistics<string>.GetFileStatistics(string filePath)
        {
            return _fileDetails.Version(filePath);
        }

        int IFileStatistics<int>.GetFileStatistics(string filePath)
        {
            return _fileDetails.Size(filePath);
        }
    }
}
