﻿using System;

namespace FileData
{
    public class FileStatisticBusinessLogic : IFileStatisticBusinessLogic
    {
        private readonly IFileStatistics<string> _fileStatisticsForVersion;
        private readonly IFileStatistics<int> _fileStatisticsForSize;

        public FileStatisticBusinessLogic(IFileStatistics<string> fileStatisticsForVersion, IFileStatistics<int> fileStatisticsForSize)
        {
            _fileStatisticsForVersion = fileStatisticsForVersion;
            _fileStatisticsForSize = fileStatisticsForSize;
        }

        public object ProcessFileStatisticData(string[] args)
        {
            if (args.Length != 2)
            {
                throw new ArgumentOutOfRangeException("Please enter two input arguments." +
                    "\n e.g. ‘-v c:/test.txt’ where '-v' is operation to perform and 'c:/test.txt' full path details of file");
            }

            switch (args[0])
            {
                case "-v":
                case "--v":
                case "/v":
                case "--version":

                    return _fileStatisticsForVersion.GetFileStatistics(args[1]);

                case "-s":
                case "--s":
                case "/s":
                case "--size":

                    return _fileStatisticsForSize.GetFileStatistics(args[1]);

                default:
                    throw new ArgumentException("Invalid arguments");
            }
        }
    }
}
