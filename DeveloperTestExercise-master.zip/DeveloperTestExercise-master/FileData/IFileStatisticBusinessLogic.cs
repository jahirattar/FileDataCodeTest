﻿namespace FileData
{
    /// <summary>
    /// Business logic for filestatistics
    /// </summary>
    public interface IFileStatisticBusinessLogic
    {
        object ProcessFileStatisticData(string[] args);
    }
}